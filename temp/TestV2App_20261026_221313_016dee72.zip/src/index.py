print('Puyal Autonomous Core Running')
